# PINAKSAGENT 2.0

This is a FastAPI-based service to generate Instagram Reels using a single prompt.

## Usage

Send a POST request to `/generate` with a prompt, and receive a generated `.mp4` video URL.